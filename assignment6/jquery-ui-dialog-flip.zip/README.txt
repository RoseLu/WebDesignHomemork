A Pen created at CodePen.io. You can find this one at http://codepen.io/jdnichollsc/pen/IcDge.

 Permite girar 2 diálogos de jQuery UI, uno adelante y otro atras.